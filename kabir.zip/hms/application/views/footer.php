    <div style="clear:both;color:#aaa; padding:20px;">

    	<hr /><center>&copy; 2021 <a target="_blank" href="#">KABIRU LABARAN BALA</a></center>

    </div>