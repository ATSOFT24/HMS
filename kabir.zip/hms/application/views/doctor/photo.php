 
 
    <form method="POST">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
   
        <div class="row pakainfo">
            <div class="col-md-3 pakainfo">
                <div id="live_camera"></div>
                <hr/>
                <input type=button value="Take Snapshot" onClick="capture_web_snapshot()">
                <input type="hidden" name="image" class="image-tag">
            </div>
            <div class="col-md-3">
                <div id="preview">Your captured image will appear here...</div>
            </div>
            <div class="col-md-12 text-center pakainfo">
                <br/>
                <button class="btn btn-primary pakainfo">Submit</button>
            </div>
        </div>
    </form>
 
  
<!-- Settings a few settings and (php capture image from camera) web attach camera -->
<script language="JavaScript">
    Webcam.set({
        width: 490,
        height: 390,
        image_format: 'jpeg',
        jpeg_quality: 90
    });
  
    Webcam.attach( '#live_camera' );
  
    function capture_web_snapshot() {
        Webcam.snap( function(site_url) {
            $(".image-tag").val(site_url);
            document.getElementById('preview').innerHTML = '<img size="20%" src="'+site_url+'"/>';
        } );
    }
</script>
 
 
